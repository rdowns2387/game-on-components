import React from 'react';
import GameItem from './GameItem';

export default {
    title: 'GameItem'
};

export const standard = () => <GameItem />